package com.fss.cms.sample.daoimpl;

import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.sql.DataSource;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringRunner;

import com.fss.cms.sample.pojo.SampleForm;

import jdk.nashorn.internal.ir.annotations.Ignore;

@RunWith(SpringRunner.class)
public class SampleDaoImplTest {
	@Mock
	Connection conn;
	@Mock
	DataSource ds;
	@Mock
	PreparedStatement ps;
	@Mock
	ResultSet rs;

	@InjectMocks
	SampleDaoImpl sampleDaoImpl;

	 @Test
	//@Ignore
	public void testFetchProgramDetails() {
		SampleForm form = new SampleForm();
		form.setBinName("VisaDebitBin");
		form.setBinNumber("400001");
		form.setProgramCode("VDP");
		form.setProgramName("Visa Debit Program");
		SampleForm responseDetails = sampleDaoImpl.fetchProgramDetails("400001");
		assertEquals(form.getBinName(), responseDetails.getBinName());
	}

	//@Test(expected = IllegalArgumentException.class)
	//@Ignore
	@Before
	public void nullCreateThrowsException() {
		System.out.println("Insidde daoimpl test");
		//new SampleDaoImpl(ds).saveBinDetails(null);
	}

	//@Test
	 @Ignore
	public void testSaveBinDetails() {
		SampleForm form = new SampleForm();
		form.setBinName("VisaPrepaidBin");
		form.setBinNumber("400002");
		form.setProgramCode("VPP");
		form.setProgramName("Visa Prepaid Program");
		boolean insertFlag = sampleDaoImpl.saveBinDetails(form);
		assertEquals(false, insertFlag);

	}

	/*
	 * @Test public void testUpdateBinDetails() { fail("Not yet implemented");
	 * SampleForm form = new SampleForm(); form.setBinName("VisaPrepaidBin");
	 * form.setBinNumber("400002"); form.setProgramCode("VPP");
	 * form.setProgramName("Visa Prepaid Program"); boolean updateFlag =
	 * sampleDaoImpl.updateBinDetails(form); assertEquals(true,updateFlag);
	 * 
	 * }
	 * 
	 * @Test public void testDeleteDetails() { fail("Not yet implemented");
	 * SampleForm form = new SampleForm(); form.setBinName("VisaPrepaidBin");
	 * form.setBinNumber("400002"); form.setProgramCode("VPP");
	 * form.setProgramName("Visa Prepaid Program"); boolean deleteFlag =
	 * sampleDaoImpl.deleteDetails(form); assertEquals(true,deleteFlag); }
	 */
}
