package com.fss.cms.sample.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fss.cms.sample.pojo.SampleForm;
import com.fss.cms.sample.service.SampleService;

@RestController
public class SampleController {
	@Autowired
	SampleService sampleService;

	
	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public SampleForm fetchProgramDetails(@PathVariable("id") String binNo) {
		SampleForm form;
		form = sampleService.fetchProgramDetails(binNo);
		return form;
	}
	
	public SampleForm insertProgramDetails(@RequestBody SampleForm form) {
		
		form = sampleService.saveProgramDetails(form);
		return form;
	}
	
	public SampleForm updateProgramDetails(@RequestBody SampleForm form) {
		SampleForm oldData = sampleService.fetchProgramDetails(form.getBinNumber());
		if(oldData == null) {
			form.setResponseCode("99");
			form.setResponseMessage("Invalid details");
			
		}else {
			form = sampleService.updateProgramDetails(form);
		}
	return form;
	}
	
}
