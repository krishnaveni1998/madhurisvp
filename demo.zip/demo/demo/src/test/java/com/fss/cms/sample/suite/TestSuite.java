package com.fss.cms.sample.suite;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import com.fss.cms.sample.controller.SampleControllerTest;
import com.fss.cms.sample.service.SampleServiceTest;

@RunWith(Suite.class)


@Suite.SuiteClasses({SampleControllerTest.class,SampleServiceTest.class})
public class TestSuite {

}
