package com.fss.cms.sample.dao;

import org.springframework.stereotype.Component;

import com.fss.cms.sample.pojo.SampleForm;

@Component
public interface SampleDao {
	
	public SampleForm fetchProgramDetails(String binNo);

	public boolean saveBinDetails(SampleForm sampleForm);
	
	public boolean updateBinDetails(SampleForm form);
	
	public boolean deleteDetails(SampleForm form);
}
