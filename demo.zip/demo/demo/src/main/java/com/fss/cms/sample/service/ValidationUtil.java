package com.fss.cms.sample.service;

import java.util.regex.Pattern;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Service
public class ValidationUtil {
	
	public boolean isNull(String data) {
		if(data == null || data == "")
			return true;
		return false;
	}
	
	public boolean isNumeric(String data) {
		Pattern pattern = Pattern.compile("-?\\d+(\\.\\d+)?");
		
			return pattern.matcher(data).matches();
		
		
	}
}
