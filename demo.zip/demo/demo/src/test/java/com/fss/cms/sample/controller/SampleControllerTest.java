package com.fss.cms.sample.controller;

import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.fss.cms.sample.pojo.SampleForm;
import com.fss.cms.sample.service.SampleService;

@RunWith(SpringRunner.class)
public class SampleControllerTest {

	@Mock
	private SampleService service;
	
	@InjectMocks
	SampleController controller;

	@Before
	public void executeBeforeMethod() {
		
		System.out.println("Method has been executed before test method");
	}
	
	@After
	public void executeAfterMethod() {
		System.out.println("Method has been executed after test method");
	}

	@BeforeClass
	public static void executeFirst() {
		System.out.println("Started executing testcases in controller");
	}
	
	@AfterClass
	public static void executeLast() {
		System.out.println("Completed executing testcases in controller");
	}
	
	@Test
	public void testFetchProgramDetailsPositive() {
		//fail("Not yet implemented");
		SampleForm form = new SampleForm();
		form.setBinNumber("400001");
		form.setBinName("VisaDebitBin");
		form.setProgramCode("VDP");
		form.setProgramName("Visa Debit Program");
		
		SampleForm responseForm = new SampleForm();
		responseForm.setBinNumber("400001");
		responseForm.setBinName("VisaDebitBin");
		responseForm.setProgramCode("VDP");
		responseForm.setProgramName("Visa Debit Program");
		
		Mockito.when(service.fetchProgramDetails(Mockito.anyString())).thenReturn(form);
		assertEquals(responseForm.getBinNumber(),controller.fetchProgramDetails(form.getBinNumber()).getBinNumber()
				);
	}
	
	@Test
	public void testFetchProgramDetailsNegative() {
		//fail("Not yet implemented");
		SampleForm form = new SampleForm();
		form.setBinNumber("400002");
		form.setBinName("VisaDebitBin");
		form.setProgramCode("VDP");
		form.setProgramName("Visa Debit Program");
		
		SampleForm responseForm = new SampleForm();
		responseForm.setBinNumber("");
		responseForm.setBinName("");
		responseForm.setProgramCode("");
		responseForm.setProgramName("");
		
		Mockito.when(service.fetchProgramDetails(Mockito.anyString())).thenReturn(form);
		assertNotEquals(responseForm,controller.fetchProgramDetails(form.getBinNumber()));
	
	
	}
	
	@Test
	public void testInsertProgramDetails() {
		SampleForm form = new SampleForm();
		form.setBinNumber("400003");
		form.setBinName("MasterDebitBin");
		form.setProgramCode("MDP");
		form.setProgramName("Master Debit Program");
		form.setResponseCode("0");
		SampleForm responseForm = new SampleForm();
		responseForm.setBinNumber("400003");
		responseForm.setBinName("MasterDebitBin");
		responseForm.setProgramCode("MDP");
		responseForm.setProgramName("Master Debit Program");
		responseForm.setResponseCode("0");
		Mockito.when(service.saveProgramDetails(Mockito.any())).thenReturn(form);
		assertEquals(responseForm.getResponseCode(),controller.insertProgramDetails(form).getResponseCode());
	}
}
